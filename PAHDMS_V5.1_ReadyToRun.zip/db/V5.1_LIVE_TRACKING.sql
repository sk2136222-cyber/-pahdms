-- =====================================================================
-- PAHDMS V5.1 - Employee Live Location Tracking
-- =====================================================================
-- Adds a single-row-per-user "current location" table used by the
-- new Live Tracking page (live-tracking.html). Every protected page
-- pings its own user's location into this table every ~30s
-- (js/common.js -> startLiveLocationTracking); the tracking page
-- polls the table and plots everyone on a map.
--
-- SAME CAVEAT AS V5.1_RLS_POLICIES.sql: the policies below rely on
-- auth.uid(), which is only populated for sessions that went through
-- real Supabase Auth (db.auth.signInWithPassword). Legacy
-- (RPC-password) sessions have no JWT, so until every account is
-- migrated (see V5.1_RLS_POLICIES.sql), those sessions will be
-- blocked by RLS from writing/reading this table too. Apply
-- V5.1_RLS_POLICIES.sql's migration steps first if you haven't.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Table: one row per user, overwritten on every ping (no history)
-- ---------------------------------------------------------------------
create table if not exists public.user_locations (
    user_id           uuid primary key references public.users(id) on delete cascade,
    full_name         text,
    role              text,
    institution_id    uuid references public.institutions(id),
    institution_name  text,
    latitude          double precision not null,
    longitude         double precision not null,
    accuracy          double precision,
    updated_at        timestamptz not null default now()
);

create index if not exists user_locations_updated_at_idx
    on public.user_locations (updated_at desc);

-- ---------------------------------------------------------------------
-- 2. Row Level Security
--    - A user may only insert/update/delete THEIR OWN row.
--    - Any authenticated user may read every row (the tracking page
--      needs to see everyone; tighten to admin-only roles here if
--      that's too broad for your rollout).
-- ---------------------------------------------------------------------
alter table public.user_locations enable row level security;

drop policy if exists "user_locations_select_authenticated" on public.user_locations;
create policy "user_locations_select_authenticated"
    on public.user_locations
    for select
    to authenticated
    using (true);

drop policy if exists "user_locations_upsert_own_row" on public.user_locations;
create policy "user_locations_upsert_own_row"
    on public.user_locations
    for insert
    to authenticated
    with check (user_id = (select id from public.current_app_user()));

drop policy if exists "user_locations_update_own_row" on public.user_locations;
create policy "user_locations_update_own_row"
    on public.user_locations
    for update
    to authenticated
    using (user_id = (select id from public.current_app_user()))
    with check (user_id = (select id from public.current_app_user()));

drop policy if exists "user_locations_delete_own_row" on public.user_locations;
create policy "user_locations_delete_own_row"
    on public.user_locations
    for delete
    to authenticated
    using (user_id = (select id from public.current_app_user()));

-- ---------------------------------------------------------------------
-- 3. Optional housekeeping: drop stale rows (e.g. run on a schedule)
--    so someone who hasn't opened the app in days doesn't linger on
--    the map forever. The tracking page also greys out anything
--    older than 10 minutes, so this is just table hygiene.
-- ---------------------------------------------------------------------
-- delete from public.user_locations where updated_at < now() - interval '7 days';
